import pandas as pd

# Utility libraries
import logging

# logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


def get_data():
    """ push data to leaflet map """

    # get data
    # here is where you would normally get your data from a database
    d = [(27.33,88.60,'Store 1',10,43,'retail'),
         (38.5556,-121.4689,'Store 2',100,65,'commercial'),
         (13.75,100.4833,'Store 3',5000,657,'commercial'),
         (23.28,-106.37,'Store 4',2,46,'commercial'),
         (36,-86,'Store 5',20,45,'commercial'),
         (45,-114,'Store 6',25,32,'commercial'),
         (13,80.22,'Store 7',500,98,'retail'),
         (14.1,-87.2167,'Store 8',54,345,'retail'),
         (37.3353,-121.8813,'Store 9',75,8,'retail'),
         (49.75,15.75,'Store 10',99,5,'retail'),
         (19,-70.6667,'Store 11',150,75,'retail'),
         (37.3333,-121.9,'Store 12',5500,33,'retail'),
         (25.5,94,'Store 13',2,998,'retail')]

    # create dataframe     
    df = pd.DataFrame(d, columns=['lat','lon','name','radius','revenue','type'])

    # convert to json
    return df.to_json(orient='records')