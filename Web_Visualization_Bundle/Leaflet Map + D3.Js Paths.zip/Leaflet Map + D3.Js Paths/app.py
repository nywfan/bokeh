# Webserver stuff
import tornado.httpserver
import tornado.ioloop
import tornado.web
from tornado.options import define, options

# Utility libraries
import os
import os.path
import logging
import datetime
from socket import gethostbyname, gethostname
import time
import json

# logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# options
define("port", default=8888, help="run on the given port", type=int)  
define("debug", default=True, type=bool)

# variables
title = 'Leaflet Path Examples'

class Application(tornado.web.Application):
    """ main """
    def __init__(self):
        handlers = [(r"/", Lesson1),
                    (r"/lesson1", Lesson1),
                    (r"/lesson2", Lesson2),
                    (r"/lesson3", Lesson3),
                    (r"/lesson4", Lesson4),   
                    (r"/lesson5", Lesson5),  
                    (r"/lesson6", Lesson6),                    
                    (r"/.*", NotFound)]
        
        settings = dict(
                template_path=os.path.join(os.path.dirname(__file__), "templates"),
                static_path=os.path.join(os.path.dirname(__file__), "static"),
                gzip=True,
                debug=True
        )
        
        tornado.web.Application.__init__(self, handlers, **settings)
      


class BaseHandler(tornado.web.RequestHandler):
    """ base class for all requests """
    def _handle_request_exception(self, e):
        self.render('error.html',
                    main_title = title,
                    err = e
        )	
            
class Lesson1(BaseHandler):
    """ index page """
    def get(self):
        self.render('01 - Lesson.html',
                    main_title = title
        )

class Lesson2(BaseHandler):
    """ index page """
    def get(self):
        self.render('02 - Lesson.html',
                    main_title = title
        )

class Lesson3(BaseHandler):
    """ index page """
    def get(self):
        self.render('03 - Lesson.html',
                    main_title = title
        )  

class Lesson4(BaseHandler):
    """ index page """
    def get(self):
        self.render('04 - Lesson.html',
                    main_title = title
        ) 

class Lesson5(BaseHandler):
    """ index page """
    def get(self):
        self.render('05 - Lesson.html',
                    main_title = title
        )  

class Lesson6(BaseHandler):
    """ index page """
    def get(self):
        self.render('06 - Lesson.html',
                    main_title = title
        )         

class NotFound(BaseHandler):
    """ default page for unknown urls """
    def get(self):
        self.render('notfound.html',
            main_title = title
        )       

# Start the server
if __name__ == "__main__":
    tornado.options.parse_command_line()
    host_ip = gethostbyname(gethostname())
    msg = '\n\n' + r'Server Running at http://localhost:' + str(options.port) + r'/' + '\n\n' + 'HostName: ' + gethostname() + '\n\n' + 'Host IP: ' + host_ip + '\n\n' + r'To close press ctrl + c'
    logger.info(msg)
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)    
    tornado.ioloop.IOLoop.instance().start()
    
    